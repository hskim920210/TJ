package tje.jdbc.util;

public class JDBCConstraints {
	public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	
	public static final String JDBC_URL = "jdbc:mysql://localhost:3306/chat?serverTimezone=UTC";
	public static final String JDBC_USER = "root";
	public static final String JDBC_PASSWORD = "SystemManager304";
}
